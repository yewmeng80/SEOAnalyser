﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SEOAnalyser;
using SEOAnalyser.Common;
using System.IO;

namespace SEOAnalyserTests.Common
{
    [TestClass]
    public class FactoryTest
    {
        [TestMethod]
        public void CreateAnalyserInstance_TextAnalyserType_CreateTextAnalyserInstance()
        {
            var anaylser = Factory.CreateAnalyserInstance("1", Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "stopWords.json"));
            bool valid = anaylser.GetType() == typeof(TextAnalyser);
            Assert.IsTrue(valid);
        }

        [TestMethod]
        public void CreateAnalyserInstance_UrlAnalyserType_CreateUrlAnalyserInstance()
        {
            var anaylser = Factory.CreateAnalyserInstance("2", Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "stopWords.json"));
            bool valid = anaylser.GetType() == typeof(URLAnalyser);
            Assert.IsTrue(valid);
        }

        [TestMethod]
        public void Handle_InvalidAnalyserType_ThrowArgumentException()
        {
            try
            {
                var anaylser = Factory.CreateAnalyserInstance("3", "");
                Assert.Fail();
            }
            catch (ArgumentException)
            {
            }
            catch (Exception)
            {
                Assert.Fail();
            }
        }
    }
}