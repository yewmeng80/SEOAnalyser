﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SEOAnalyser.Common;
namespace SEOAnalyserTests.Common
{
    [TestClass]
    public class UtilTest
    {
        [TestMethod]
        public void GetExternalLinks_TextWithoutUrl_ReturnEmptyList()
        {
            var list = Util.GetExternalLinks("test 123");
            Assert.AreEqual(list.Count, 0);
        }

        [TestMethod]
        public void GetExternalLinks_TextWithUrls_ReturnUrlList()
        {
            var list = Util.GetExternalLinks("Please go to https://efg.com?a=1");
            Assert.AreEqual(list.Count, 1);
        }

        [TestMethod]
        public void GetWords_StringWith2Words_Return2Words()
        {
            var list = Util.GetWords("Go home.");
            Assert.AreEqual(list.Count, 2);
        }

        [TestMethod]
        public void RemoveStopWords_2Words_Return1Word()
        {
            var words = new List<string>() { "Simon" , "is" };
            var stopWords = new List<string>() { "a", "is" };

            var list = Util.RemoveStopWords(words, stopWords);
            Assert.AreEqual(list.Count, 1);
        }

    }
}
