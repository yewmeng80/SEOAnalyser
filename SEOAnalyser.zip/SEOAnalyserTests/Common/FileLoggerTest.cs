﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SEOAnalyser.Common;
using System.Configuration;
using System.IO;

namespace SEOAnalyserTests
{
    [TestClass]
    public class FileLoggerTest
    {
        [TestMethod]
        public void Handle_ParameterValueIsEmptyString_ThrowArgumentNullException()
        {
            try
            {
                var logger = new FileLogger(@"c:\log");
                logger.Handle(string.Empty);
                Assert.Fail();
            }
            catch (ArgumentNullException)
            {
            }
            catch (Exception)
            {
                Assert.Fail();
            }
        }        
    }
}
