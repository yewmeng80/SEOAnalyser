﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SEOAnalyser;
using SEOAnalyser.Common;
using System.IO;

namespace SEOAnalyserTests.Analyser
{
    [TestClass]
    public class TextAnalyserTest
    {
        [TestMethod]
        public void Process_AnalysisIsFalse_Return3Words1Link()
        {
            var anaylser = Factory.CreateAnalyserInstance("1", Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "stopWords.json"));
            var result = anaylser.Process("you may visit https://www.abc.com?aa=1", false);
            Assert.AreEqual(result.Words.Count, 3);
            Assert.AreEqual(result.ExternalLinks.Count, 1);
        }

        [TestMethod]
        public void Process_AnalysisIsTrue_Return2Words2Links()
        {
            var anaylser = Factory.CreateAnalyserInstance("1", Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "stopWords.json"));
            var result = anaylser.Process("you may visit https://www.abc.com or https://www.efg.com", true);
            Assert.AreEqual(result.Words.Count, 2);
            Assert.AreEqual(result.ExternalLinks.Count, 2);
        }
    }
}
