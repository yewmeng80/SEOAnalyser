﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SEOAnalyser;
using SEOAnalyser.Common;
using System.IO;
using HtmlAgilityPack;

namespace SEOAnalyserTests.Analyser
{
    [TestClass]
    public class URLAnalyserTest
    {
        [TestMethod]
        public void Process_InvalidUrlFormat_ThrowArgumentException()
        {
            try
            {
                var analyser = Factory.CreateAnalyserInstance("2", Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "stopWords.json"));
                analyser.Process("aaa", true);
                Assert.Fail();
            }
            catch (ArgumentException)
            {
            }
            catch (Exception)
            {
                Assert.Fail();
            }
        }       
    }
}
