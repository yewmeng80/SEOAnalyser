﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.IO;

namespace SEOAnalyser.Common
{
    public class FileLogger : ILogger
    {
        private readonly string _logFilePath;

        public FileLogger(string logFilePath)
        {
            _logFilePath = logFilePath;
        }

        public void Handle(string value)
        {
            if (string.IsNullOrEmpty(value))
                throw new ArgumentNullException("SEOAnalyser.Common.FileLogger - Value cannot be empty.");
            
            if (!Directory.Exists(_logFilePath))
            {
                Directory.CreateDirectory(_logFilePath);
            }

            var logFile = Path.Combine(_logFilePath, DateTime.Now.ToString("yyyyMMdd") + ".txt");
            if (!File.Exists(logFile))
            {
                File.Create(logFile);
            }

            using (StreamWriter sw = File.AppendText(logFile))
            {
                sw.WriteLine(value);
            }
        }
    }
}