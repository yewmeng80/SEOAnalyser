﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Text.RegularExpressions;
using System.IO;
using Newtonsoft.Json;

namespace SEOAnalyser.Common
{
    public static class Util
    {
        public static List<string> GetExternalLinks(string text)
        {
            var urlList = new List<string>();           
            MatchCollection mc = Regex.Matches(text, @"(http|ftp|https)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?");
            foreach (Match match in mc)
            {
                urlList.Add(match.Value);
            }

            return urlList;
        }

        public static List<string> GetWords(string text)
        {
            text = Regex.Replace(text, @"(http|ftp|https)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?", "");
            var list = Regex.Split(text, @"\W+");
            return list.Where(x => !string.IsNullOrEmpty(x.Trim())).ToList();
        }

        public static List<string> RemoveStopWords(List<string> words, List<string> stopWords)
        {
            return words.Where(word => !stopWords.Contains(word)).ToList();
        }

        public static List<string> GetStopWords(string path)
        {
            var json = File.ReadAllText(path);
            return JsonConvert.DeserializeObject<List<string>>(json);
        }

    }
}