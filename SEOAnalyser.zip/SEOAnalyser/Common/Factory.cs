﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SEOAnalyser.Common
{
    public static class Factory
    {
        public static Analyser CreateAnalyserInstance(string type, string stopWordsFilePath)
        {
            var stopWords = Util.GetStopWords(stopWordsFilePath);

            switch (type)
            {
                case "1":
                    return new TextAnalyser(stopWords);
                case "2":
                    return new URLAnalyser(stopWords);
                default:
                    throw new ArgumentException("Invalid Anaylser type");
            }

        }
    }
}