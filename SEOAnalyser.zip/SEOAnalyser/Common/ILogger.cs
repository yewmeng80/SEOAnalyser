﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SEOAnalyser.Common
{
    public interface ILogger
    {
        void Handle(string value);
    }
}