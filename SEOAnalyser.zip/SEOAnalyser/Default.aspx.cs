﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HtmlAgilityPack;
using NUglify;
using System.Text;
using System.Text.RegularExpressions;
using SEOAnalyser.Common;

namespace SEOAnalyser
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            divMessage.Visible = false;
        }

        protected void btnProcess_Click(object sender, EventArgs e)
        {
            ILogger logger = new FileLogger(Server.MapPath("~/log"));

            try
            {
                Analyser analyser = Factory.CreateAnalyserInstance(ddlFormat.SelectedValue, Server.MapPath("~/stopWords.json"));
                var result = analyser.Process(txtInput.Text, cbAnalysis.Checked);
                rptWord.DataSource = result.Words;
                rptWord.DataBind();
                rptLink.DataSource = result.ExternalLinks;
                rptLink.DataBind();
                DisplayMessage(false, "Input has been proccessed successfully.");
            }
            catch (Exception ex)
            {
                logger.Handle(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                logger.Handle(string.Format("Input : {0}", txtInput.Text));
                logger.Handle(string.Format("Format : {0}", ddlFormat.SelectedItem.Text));
                logger.Handle(string.Format("Analysis : {0}", cbAnalysis.Checked));
                logger.Handle(string.Format("Message : {0}", ex.ToString()));
                DisplayMessage(true, "An error occured, procces failed.");
            }
        }

        private void DisplayMessage(bool isError, string message)
        {
            divMessage.Visible = true;            
            divMessage.InnerText = message;
            if (!isError)
                divMessage.Attributes.Add("class", "alert alert-success");
            else
                divMessage.Attributes.Add("class", "alert alert-danger");
        }        
       
    }
   
}