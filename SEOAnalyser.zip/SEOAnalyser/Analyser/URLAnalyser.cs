﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HtmlAgilityPack;
using NUglify;
using System.Text.RegularExpressions;
using SEOAnalyser.Common;

namespace SEOAnalyser
{
    public class URLAnalyser : Analyser
    {
        public URLAnalyser(List<string> stopWords) : base(stopWords)
        {
        }

        public override Result Process(string url, bool isAnalysis)
        {
            if (!Regex.IsMatch(url, @"^(http|https)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?$"))
                throw new ArgumentException("Invalid Url.");

            var web = new HtmlWeb();
            var doc = web.Load(url);
            var body = doc.DocumentNode.SelectSingleNode("//body");
            var text = Uglify.HtmlToText(body.OuterHtml);

            var words = new List<string>();
            words = Util.GetWords(text.Code);

            if (isAnalysis)
            {
                words = Util.RemoveStopWords(words, base._stopWords);
            }

            var result = new Result();
            var wordList = new List<Word>();
            var groupBy = words.GroupBy(word => word).ToDictionary(group => group.Key, group => group.Count());
            foreach (var item in groupBy)
            {
                wordList.Add(new Word() { Name = item.Key, Count = item.Value, CountInMetaTags = 0 });
            }           

            var links = new List<String>();
            var html = doc.DocumentNode.SelectSingleNode("//html");
            links = Util.GetExternalLinks(html.OuterHtml);
            result.ExternalLinks = links.GroupBy(link => link).ToDictionary(group => group.Key, group => group.Count());

            var metaTags = doc.DocumentNode.SelectNodes("//meta");
            foreach (var tag in metaTags.ToList())
            {
                foreach (var item in tag.Attributes)
                {
                    if (wordList.Any(x => x.Name == item.Name))
                    {
                        var word = wordList.SingleOrDefault(x => x.Name == item.Name);
                        word.CountInMetaTags += 1;
                    }

                    var metaWords = Util.GetWords(item.Value);

                    foreach (var metaWord in metaWords)
                    {
                        if (wordList.Any(x => x.Name == metaWord))
                        {
                            var word = wordList.SingleOrDefault(x => x.Name == metaWord);
                            word.CountInMetaTags += 1;
                        }
                    }                   

                }
            }
            
            result.Words = wordList;
            return result;
        }
    }
}