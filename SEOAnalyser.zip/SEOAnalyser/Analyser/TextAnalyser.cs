﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SEOAnalyser.Common;
using Newtonsoft.Json;

namespace SEOAnalyser
{
    public class TextAnalyser : Analyser
    {
        public TextAnalyser(List<string> stopWords) : base(stopWords)
        {
        }

        public override Result Process(string text, bool isAnalysis)
        {
            var words = new List<string>();
            var links = new List<string>();

            words = Util.GetWords(text);
            links = Util.GetExternalLinks(text);

            if (isAnalysis)
            {               
                words = Util.RemoveStopWords(words, base._stopWords);
            }

            var result = new Result();
            var wordList = new List<Word>();
            var groupBy = words.GroupBy(word => word).ToDictionary(group => group.Key, group => group.Count());
            foreach (var item in groupBy)
            {
                wordList.Add(new Word() { Name = item.Key, Count = item.Value, CountInMetaTags = 0 });
            }
            result.Words = wordList;
            result.ExternalLinks = links.GroupBy(link => link).ToDictionary(group => group.Key, group => group.Count());

            return result;
        }
    }
}