﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SEOAnalyser
{
    public class Result
    {
        public List<Word> Words { get; set; }
        
        public Dictionary<string, int> ExternalLinks { get; set; }
    }

    public class Word
    {
        public string Name { get; set; }

        public int Count { get; set; }

        public int CountInMetaTags { get; set; }
    }
}