﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SEOAnalyser
{
    public abstract class Analyser
    {
        protected List<string> _stopWords;

        public Analyser(List<string> stopWords)
        {
            _stopWords = stopWords;
        }

        public abstract Result Process(string input, bool isAnalysis);
    }
}